﻿var HomeIndexPage = (function () {

    function init() {
        handler();

    }


    function handler() {
       
    }
    return {
        Init: init
    };

})();