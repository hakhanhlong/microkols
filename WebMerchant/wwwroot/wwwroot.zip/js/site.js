﻿$().ready(function () {

    App.Init();
});