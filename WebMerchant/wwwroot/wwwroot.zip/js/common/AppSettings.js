﻿var AppSettings = {
    IsAuthenticated: false,
    CurrentUser: {
        Username: '',
        Name: '',
        Type: -1,
        Balance: 0
    },
};